<div id="logo-nv">
    <a href="index.php"><img src="<?= RUTA_IMGS ?>/logo-h-dMode.png" alt="" height="30"></a>
</div>