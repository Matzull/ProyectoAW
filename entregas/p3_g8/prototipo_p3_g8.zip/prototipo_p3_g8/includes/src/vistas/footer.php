<footer class="footer">
	<div class="footer-container">

		<div class="footer-column">
			<h4 class="title">Contacto</h4>
			<ul>
				<li><a href="contacto.php"> Danos tu opinión</a></li>
				<li><a href="contacto.php"> Redes sociales</a></li>
			</ul>
		</div>

		<div class="footer-column">
			<h4 class="title">Información</h4>
			<ul>
				<li><a href="FAQ.php"> FAQ</a></li>
			</ul>
		</div>

		<div class="footer-column">
			<h4 class="title">Mercado de kernels</h3>
			<ul>
				<li><a href="kernel_marketplace.php">Kernels mejor pagados</a></li>
				<li><a href="kernel_marketplace.php">Kernels nuevos</a></li>
			</ul>
		</div>

		<div class="footer-column">
			<h4 class="title">Rankings</h3>
			<ul>
				<li><a href="ranking.php">Ránking de kernels</a></li>
				<li><a href="ranking.php">Mejores usuarios</a></li>
			</ul>
		</div>



	</div>
	<div class="footer-bottom">
		<p class="no-margin">Derechos de autor © 2023 | Todos los derechos reservados.</p>
	</div>
</footer>