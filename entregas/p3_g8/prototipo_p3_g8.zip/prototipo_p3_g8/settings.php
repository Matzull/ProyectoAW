<?php
require 'includes/config.php';

if (!isset($_SESSION['user_email'])) {
    header("location: login.php");
    die();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajustes</title>
    <link rel="stylesheet" href="<?= RUTA_CSS ?>/nav_bar.css">
    <link rel="stylesheet" href="<?= RUTA_CSS ?>/user_nav_bar.css">
    <link rel="stylesheet" href="<?= RUTA_CSS ?>/settings.css">
</head>

<body>
    <?php require_once("./includes/src/vistas/user_nav_bar.php") ?>
    <?php require_once("./includes/src/vistas/nav_bar.php") ?>
    <div class="main-container">
        <div id="user-panel">
            <div class="header">
                <img src="./<?= RUTA_SVG ?>/Settings_i.svg" alt="" width="44">
                <h2>AJUSTES</h2>
            </div>
            <div class="sections-container">
                <div class="section">
                    <div class="section-row">
                        <div class="section-content">
                            <h2>Mi foto de Perfil</h2>
                            <div class="photo-panel">
                                <img class="circle-border" src="https://picsum.photos/100/100" alt="" width="100" height="100">
                                <div class="options">
                                    <button class="button c-h-blue" >Cambiar Foto</button>
                                    <button class="button c-h-b-blue" >Eliminar Foto</button>
                                </div>
                            </div>
                        </div>
                        <div class="section-content">
                            <h2>Nombre de Usuario</h2>
                            <div>
                                <div class="field-button">
                                    <input class="input-field" type="text" name="" id="" value="NombreDeUsuario" disabled>
                                    <button class="button c-h-blue" >Editar</button>
                                </div>
                                <button class="button c-h-b-blue" >Utilizar Mi Nombre Real</button>
                            </div>
                        </div>
                    </div>
                    <div class="section-row">
                        <div class="section-content">
                            <h2>Mis Datos Personales</h2>
                            <h3>Nombre</h3>
                            <div class="field-button">
                                <input class="input-field" type="text" name="" id="" value="Nombre" disabled>
                                <button class="button c-h-blue" >Editar</button>
                            </div>
                            <h3>Apellidos</h3>
                            <div class="field-button">
                                <input class="input-field" type="text" name="" id="" value="Apellidos" disabled>
                                <button class="button c-h-blue" >Editar</button>
                            </div>
                            <h3>Correo electrónico</h3>
                            <div class="field-button">
                                <input class="input-field" type="text" name="" id="" value="example@gmail.com" disabled>
                                <button class="button c-h-blue" >Editar</button>
                            </div>
                            <h3>Método de pago</h3>
                            <button class="button c-h-blue" >Mostrar información de pago</button>
                        </div>
                        <div class="section-content">
                            <h2>Opciones</h2>
                            <h3>Opciones del perfil público</h3>
                            <div class="checkbox-list">
                                <div>
                                    <input type="checkbox" name="" id="show-real-name">
                                    <label for="show-real-name">Mostrar mi nombre real</label>
                                </div>
                                <div>
                                    <input type="checkbox" name="" id="show-my-wallet">
                                    <label for="show-my-wallet">Mostrar mi cartera</label>
                                </div>
                            </div>
                            <button class="button c-h-blue"  onclick="location.href='profile_view.php?id=<?= $_SESSION['user_email'] ?>'">
                                Ver perfil como un tercero
                            </button>
                            <h3>Otras opciones</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>